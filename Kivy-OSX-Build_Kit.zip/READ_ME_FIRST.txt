Read me first!!!

$ cd <this directory>

Find a subdirectory in this kit called yourapp and,
  Copy your executable main.py script into this directory. 
  In the case of CW_Remote, that would be:
  $ cp <CW_Remote's directory>/CW_Remote.py ./yourapp/main.py

  If there are ANY sub-modules, they must be also copied to where yourapp
  Any sub-modules contained in sub-directories, must be copied entire to yourapp
  
Does this mean main.py has to executable from <this directory>/yourapp? You bet it does.

edit buildtrowel.sh such that, for your dependency list:

$ pip install <your script's first dependency> -t .
$ pip install <your script's second dependency> -t .
$ pip install <your script's third dependency> -t .
$ ... the rest of your dependency list (except the last handled below)
$ pip install <your script's last dependency> -t .


$ sh buildtrowel.sh