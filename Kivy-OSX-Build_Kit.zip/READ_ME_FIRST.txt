Read me first!!!

$ cd <this directory>

Copy your executable main.py script into this directory. 
In the case of CW_Remote, that would be:
$ cp <CW_Remote's directory>/CW_Remote.py main.py


edit buildtrowel.sh such that, for your dependency list:

$ pip install <your script's first dependency> -t .
$ pip install <your script's second dependency> -t .
$ pip install <your script's third dependency> -t .
$ ... the rest of your dependency list (except the last handled below)
$ pip install <your script's last dependency> -t .


$ sh buildtrowel.sh