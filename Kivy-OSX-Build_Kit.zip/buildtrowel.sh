#!/bin/bash
# Make a copy of the kit app
cp -a HellowWorld.app MyApp.app

# Install script
yes | cp -R  main.py ./MyApp.app/Contents/Resources/yourapp/

# Install app icons
yes | cp -R appIcon.icns ./MyApp.app/Contents/Resources/
yes | cp -R appIcon.icns ./MyApp.app/Contents/Resources/yourapp/

# Fix launched window icons
yes | cp -R kivy-icon-16.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-24.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-32.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-48.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-64.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-64.ico ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-128.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-256.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/
yes | cp -R kivy-icon-512.png ./MyApp.app/Contents/Resources/kivy/kivy/data/logo/

# Fix launched window icons
yes | cp -R kivy-icon-16.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-24.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-32.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-48.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-64.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-64.ico ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-128.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-256.png ./MyApp.app/Contents/Resources/.kivy/icon/
yes | cp -R kivy-icon-512.png ./MyApp.app/Contents/Resources/.kivy/icon/

# Install dependencies
cd ./MyApp.app/Contents/Resources/venv/lib/python2.7/site-packages
pip install urllib3 -t .
pip install botocore -t .
pip install boto3 -t .
